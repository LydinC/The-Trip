import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by User on 17/08/2018.
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException{
        Scanner sc = new Scanner(System.in);

        //Input
        System.out.println("Please input the exact filename (ex: 'TripCostsExample.txt'):");
        String filename = sc.next();

        ArrayList<Double> expenses = new ArrayList<Double>();
        double totalExpense = 0.0;

        //Processing data
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String lineRead;
            int numStudentsForTrip = 0;

            while (!(lineRead = br.readLine()).equals("0")) {
                // if number of students is not set (=0), then read line and set it accoringly
                if (numStudentsForTrip == 0) {
                    numStudentsForTrip = Integer.parseInt(lineRead);
                }else{
                    //for each student, add up the expenses listed in the file
                    for (int i = 0; i < numStudentsForTrip; i++) {
                        expenses.add(Double.parseDouble(lineRead));
                        if(i < numStudentsForTrip -1){
                            lineRead = br.readLine();
                        }
                        totalExpense += expenses.get(i);
                    }

                    //calculate average of expenses
                    double average = ((totalExpense / (double) numStudentsForTrip) * 100.0) / 100.0;

                    double negativeDifference = 0.0;
                    double positiveDifference = 0.0;

                    //for each student, calculate the difference from the average to get the overall positive and negative differences
                    for (int i = 0; i < numStudentsForTrip; i++) {
                        if (expenses.get(i) > average)
                            positiveDifference += (long) ((expenses.get(i) - average) * 100.0) / 100.0;
                        else
                            negativeDifference += (long) ((average - expenses.get(i)) * 100.0) / 100.0;
                    }

                    double difference = 0.0;

                    //get the minimum amount of money that must change hands
                    if(positiveDifference > negativeDifference){
                        difference = negativeDifference;
                    }else{
                        difference = positiveDifference;
                    }

                    //Print result
                    System.out.println("$" + difference);

                    //Reset Variables
                    numStudentsForTrip = 0;
                    expenses.clear();
                    totalExpense = 0.0;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
